﻿namespace SharedCode.Model.HttpCommand
{
    public class BaseRequest
    {
    }

    public class BaseResponse
    {
        public bool IsSuccess { get; set; }
    }
}
