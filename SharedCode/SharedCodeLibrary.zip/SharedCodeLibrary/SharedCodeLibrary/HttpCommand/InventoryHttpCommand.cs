﻿namespace SharedCode.Model.HttpCommand
{
    public class InventoryHttpCommand
    {
    }
}
